QuantumApex — Batch-1 (Core, fully implemented)

This batch contains 15 core modules (no skeletons) designed to run locally with a Local Bridge.

How to smoke-test locally:
1) Install dependencies: pip install -r requirements.txt
2) Start bridge server: uvicorn backend.bridge_server:app --host 127.0.0.1 --port 8765
3) Start demo sender (in another terminal): python local_bridge/demo_sender.py
4) Start engine runner: python backend/main_runner.py
5) Observe signals written to signals.log

All modules are implemented to a practical, production-oriented level for Batch-1.
